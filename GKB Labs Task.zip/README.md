
# GKB Labs Project

The project is a website to register user data in a database
Website consists of 2 websites. One to Add users into database and another to List down all users in Database

## Tools Used

- Python
- Flask
- HTML, CSS, Javascript
- Sql DB

## Installation

Install Fask package using command

```bash
  pip install Flask
```

## Running Website

To run the website you must run the main.py file which contains the flask server code



